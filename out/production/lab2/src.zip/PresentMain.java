public class PresentMain {
    public static void main(String[] args){
        //run the test vectors for Present
        Present cipher = new Present();
        //key = 0000 0000000000000000
        //plaintext = 0000000000000000
        //the ciphertext should be 6679c1387b228445
        cipher.initKey(0x0L,0x0L);
        long plaintext = 0x0L;
        long ciphertext = cipher.encrypt(plaintext);
        System.out.println(BitUtils.hex(ciphertext));
        //key = ffff ffffffffffffffff
        //plaintext = 0000000000000000
        //the ciphertext should be e72c46c0f5945049
        cipher.initKey(0xFFFFL,0xFFFFFFFFFFFFFFFFL);
        plaintext = 0x0L;
        ciphertext = cipher.encrypt(plaintext);
        System.out.println(BitUtils.hex(ciphertext));
        //key = 0000 0000000000000000
        //plaintext = FFFFFFFFFFFFFFFF
        //the ciphertext should be a112ffc72f68417b
        cipher.initKey(0x0L,0x0L);
        plaintext = 0xFFFFFFFFFFFFFFFFL;
        ciphertext = cipher.encrypt(plaintext);
        System.out.println(BitUtils.hex(ciphertext));
    }
}